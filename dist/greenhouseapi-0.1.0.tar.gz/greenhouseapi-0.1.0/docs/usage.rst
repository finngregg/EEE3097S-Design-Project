=====
Usage
=====

To use greenhousemonitor in a project::

    import greenhousemonitor
